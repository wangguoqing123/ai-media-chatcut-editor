#!/usr/bin/env python3
"""Install this offline Skill bundle without replacing existing folders."""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from pathlib import Path

def verify(root):
    data = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
    names = data['skills']
    if not names or any(not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', name) for name in names):
        raise ValueError('Skill 名称无效')
    entries = data['files']
    for relative, digest in entries.items():
        path = root / relative
        resolved = path.resolve()
        if path.is_symlink() or not resolved.is_relative_to(root) or not resolved.is_file():
            raise ValueError('文件缺失或路径无效：' + relative)
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('文件校验失败：' + relative)
    actual = {p.relative_to(root).as_posix() for p in (root/'skills').rglob('*') if p.is_file()}
    expected = {p for p in entries if p.startswith('skills/')}
    if actual != expected:
        raise ValueError('skills/ 存在未登记或缺失文件')
    for name in names:
        if not (root/'skills'/name/'SKILL.md').is_file():
            raise ValueError('缺少 SKILL.md：' + name)
    return names

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, help='目标 skills 目录，默认当前用户的Codex skills目录')
    parser.add_argument('--only', action='append', help='仅安装指定 Skill，可重复使用')
    parser.add_argument('--check', action='store_true', help='只校验文件与安装目标，不写入')
    args = parser.parse_args()
    try:
        root = Path(__file__).resolve().parent
        names = verify(root)
        selected = args.only if args.only else names
        if len(selected) != len(set(selected)) or any(name not in names for name in selected):
            raise ValueError('--only 必须是包内的 Skill 名称且不可重复')
        target = (args.target if args.target else Path(os.environ.get('CODEX_HOME', str(Path.home()/'.codex')))/'skills').expanduser().resolve()
        source = (root/'skills').resolve()
        if target.is_relative_to(source):
            raise ValueError('安装目标不能位于包内的 skills/ 中')
        conflicts = [name for name in selected if (target/name).exists() or (target/name).is_symlink()]
        if conflicts:
            raise ValueError('目标已有同名 Skill，未覆盖任何内容：' + ', '.join(conflicts))
        if target.exists() and not target.is_dir():
            raise ValueError('目标不是目录')
        print('文件校验通过。安装目标：' + str(target))
        print('待安装：' + ', '.join(selected))
        if args.check:
            print('仅检查，未写入。')
            return 0
        target.mkdir(parents=True, exist_ok=True)
        for name in selected:
            shutil.copytree(source/name, target/name)
            print('已安装：' + name)
        print('安装完成。若宿主未自动显示新 Skill，请重启后查看。')
        print('下一轮调用AI自媒体剪辑助手，继续检查ChatCut连接、登录和主题色。')
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print('未能完成安装：' + str(error), file=sys.stderr)
        return 1

if __name__ == '__main__':
    if sys.version_info < (3, 10):
        raise SystemExit('需要 Python 3.10 或更新版本。')
    raise SystemExit(main())
